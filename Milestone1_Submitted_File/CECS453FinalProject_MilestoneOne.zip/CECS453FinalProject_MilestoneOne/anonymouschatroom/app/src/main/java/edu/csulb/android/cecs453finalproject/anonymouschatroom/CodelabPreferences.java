package edu.csulb.android.cecs453finalproject.anonymouschatroom;

public class CodelabPreferences {

    public static final String FRIENDLY_MSG_LENGTH = "friendly_msg_length";

}
