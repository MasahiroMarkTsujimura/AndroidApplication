package edu.csulb.android.cecs453finalproject.anonymouschatroom;

/**
 * Created by ilwonson on 11/17/17.
 */

public class MyFirebaseInstanceIdService {
    private static final String TAG = "MyFirebaseIIDService";
    private static final String FRIENDLY_ENGAGE_TOPIC = "friendly_engage";

    /**
     * The Application's current Instance ID token is no longer valid and thus a new one must be requested.
     */
    public void onTokenRefresh() {
    }
}
